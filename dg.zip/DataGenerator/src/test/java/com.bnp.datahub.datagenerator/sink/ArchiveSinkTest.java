package com.bnp.datahub.datagenerator.sink;

import com.bnp.datahub.datagenerator.context.ExecutionContext;
import org.apache.commons.io.FilenameUtils;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class ArchiveSinkTest {

    @Rule
    public TemporaryFolder folder = new TemporaryFolder();

    private ArchiveSink archiveSink = new ArchiveSink(new ExecutionContext());

    @Test
    public void compressFilesTestNull() {
        assertThrows(NullPointerException.class,
                () ->
                        archiveSink.compressFiles(null, null, null)
        );
    }

    @Test
    public void compressFilesTest() throws IOException {
        File tmpFolder = folder.newFolder("targetFolder", "tmpFolder");
        File targetFolder = tmpFolder.getParentFile();

        archiveSink.compressFiles(targetFolder, tmpFolder, "archive");
        Files.walk(targetFolder.toPath())
                .filter(Files::isRegularFile)
                .map(Path::toString)
                .forEach((s) -> Assert.assertEquals(FilenameUtils.getExtension(s), "gz"));
    }
}