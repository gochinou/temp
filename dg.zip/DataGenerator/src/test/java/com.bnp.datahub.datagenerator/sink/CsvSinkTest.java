/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.sink;

import com.bnp.datahub.datagenerator.context.ExecutionContext;
import com.bnp.datahub.datagenerator.model.Config;
import com.bnp.datahub.datagenerator.parser.ConfParser;
import com.bnp.datahub.datagenerator.testUtil.Util;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Objects;

import static com.bnp.datahub.datagenerator.testUtil.Util.getResource;

public class CsvSinkTest {
    private static final Logger logger = LoggerFactory.getLogger(CsvSinkTest.class);
    private static ConfParser confParser;
    private static Config config;
    private static CsvSink csvSink;
    private static int fileNumber;
    private static GenericRecord genericRecord;
    private static Schema schema;
    private static String filePath;
    private static BufferedReader br;


    /**
     * Initiate the CsvSink configuration
     *
     * @throws IOException
     */
    @Before
    public void setUp() throws IOException, URISyntaxException {
        schema = Util.getResourceAsSchema("schemas/processTest.json");
        genericRecord = new GenericData.Record(schema);
        csvSink = new CsvSink();
        confParser = new ConfParser();
        config = confParser.deserialize(getResource("config/conf.json")).get(0);
        csvSink.init(new ExecutionContext(), config);
    }

    /**
     * Test the creation of the file
     *
     * @throws IOException
     */
    @Test
    public void createFileTest() throws IOException {
        fileNumber = 1;
        csvSink.createFile(fileNumber);
        Assert.assertTrue(Files.exists(Paths.get(csvSink.getFilePath(fileNumber))));
        csvSink.close();
    }


    /**
     * Test the process function that writes in the file already created by createFile function
     *
     * @throws IOException
     */
    @Test
    public void processTest() throws IOException {
        fileNumber = 2;
        String line;
        filePath = csvSink.getFilePath(fileNumber);
        csvSink.createFile(fileNumber);
        Assert.assertTrue(Files.exists(Paths.get(filePath)));

        //fill the generic record
        genericRecord.put("name", "dupont");
        genericRecord.put("address", "paris");
        genericRecord.put("age", 32);
        genericRecord.put("married", false);

        csvSink.process(genericRecord);

        //close the csvSink so we can reopen it to check
        csvSink.close();

        //test that the data in the file is exactly the same as the generic record data
        logger.debug("The file's path is {}", filePath);

        br = new BufferedReader(new FileReader(filePath));
        line = br.readLine();
        logger.debug("This is the line written in the file: {}", line);

        String[] record = line.split(Character.toString(config.getCsvProps().getCsvOptions().getSeparator()));

        Assert.assertTrue("The name should be Dupont", Objects.equals(genericRecord.get("name"), record[0]));
        Assert.assertEquals("The age should be 32", genericRecord.get("age"), Integer.parseInt(record[1]));
        Assert.assertTrue("The address should be paris", Objects.equals(genericRecord.get("address"), record[2]));
        Assert.assertTrue("The married situation should be false", genericRecord.get("married").equals(Boolean.parseBoolean(record[3])));
    }


    /**
     *
     */
    @Test
    public void writeHeaderTest() throws IOException {
        fileNumber = 3;
        String line;
        filePath = csvSink.getFilePath(fileNumber);
        csvSink.createFile(fileNumber);
        Assert.assertTrue(Files.exists(Paths.get(filePath)));

        //fill the generic record
        genericRecord.put("name", "dupont");
        genericRecord.put("address", "paris");
        genericRecord.put("age", 32);
        genericRecord.put("married", false);

        csvSink.writeHeader(genericRecord);

        //close the csvSink so we can reopen it to check
        csvSink.close();

        logger.debug("The file's path is {}", filePath);

        br = new BufferedReader(new FileReader(filePath));
        line = br.readLine();
        logger.debug("This is the line written in the file: {}", line);

        String[] record = line.split(Character.toString(config.getCsvProps().getCsvOptions().getSeparator()));

        //test that the header in the file is exactly the same as the generic record data
        Assert.assertTrue("It should be the name field", Objects.equals("name", record[0]));
        Assert.assertTrue("It should be the age field", Objects.equals("age", record[1]));
        Assert.assertTrue("It should be the address field", Objects.equals("address", record[2]));
        Assert.assertTrue("It should be the married field", Objects.equals("married", record[3]));
    }


    /**
     * Close the csv writer and delete the file that was created
     *
     * @throws IOException
     */
    @After
    public void tearDown() throws IOException {
        if (br != null) {
            br.close();
        }
        FileUtils.deleteDirectory(csvSink.getDirectory());
    }
}