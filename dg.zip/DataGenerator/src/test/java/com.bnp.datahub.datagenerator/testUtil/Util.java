/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.testUtil;

import com.bnp.datahub.datagenerator.context.ExecutionContext;
import com.bnp.datahub.datagenerator.generator.EventGenerator;
import com.bnp.datahub.datagenerator.model.Config;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.*;

public class Util {
    private static final Logger logger = LoggerFactory.getLogger(Util.class);

    public static final ExecutionContext CONTEXT = new ExecutionContext();
    /**
     * This method returns the schema from the schema json file in the resource folder
     *
     * @param schemaName the name of the file in resources
     * @return avro schema
     * @throws IOException
     */
    public static Schema getResourceAsSchema(String schemaName) throws IOException, URISyntaxException {
        URL resource = Util.class.getClassLoader().getResource(schemaName);
        Schema schema = new Schema.Parser().parse(new File(resource.toURI()));
        logger.debug("The schema is {}", schema);
        return schema;
    }

    /**
     * This method returns a generic record based on the given schema
     *
     * @param schemaName the schema name in resources/schemas
     * @return random generic record
     * @throws IOException, URISyntaxException
     */
    public static GenericRecord buildGenericRecord(String schemaName) throws IOException, URISyntaxException {
        Schema schema = Util.getResourceAsSchema(schemaName);
        EventGenerator eventGenerator = new EventGenerator(CONTEXT, schema);
        return eventGenerator.generate();
    }

    /**
     * @param config
     * @return
     */
    public static List<GenericRecord> consumeEvents(Config config) {
        List<GenericRecord> actual = new ArrayList<>();
        Properties consumerConfig = new Properties();
        consumerConfig.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, config.getKafkaProps().getBootstrapServers());
        consumerConfig.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        consumerConfig.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, KafkaAvroDeserializer.class);
        consumerConfig.put("schema.registry.url", config.getKafkaProps().getSchemaRegistry());

        KafkaConsumer<String, GenericRecord> consumer = new KafkaConsumer<>(consumerConfig);
        TopicPartition partition = new TopicPartition(config.getKafkaProps().getTopicName(), 0);
        consumer.assign(Arrays.asList(partition));
        consumer.seek(partition, 0);

        ConsumerRecords<String, GenericRecord> records = consumer.poll(100);

        Iterator<ConsumerRecord<String, GenericRecord>> iterator = records.records(config.getKafkaProps().getTopicName()).iterator();
        while (iterator.hasNext()) {
            actual.add(iterator.next().value());
        }
        consumer.close();
        return actual;
    }

    /**
     * This method returns, from the resources folder, the file which name is
     * the given parameter
     *
     * @param fileName the file name in resources
     * @return the resource file
     * @throws URISyntaxException
     */
    public static File getResource(String fileName) throws URISyntaxException {
        URL resource = Util.class.getClassLoader().getResource(fileName);
        return new File(resource.toURI());
    }
}