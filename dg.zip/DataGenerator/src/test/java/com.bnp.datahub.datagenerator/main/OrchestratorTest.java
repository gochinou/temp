package com.bnp.datahub.datagenerator.main;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OrchestratorTest {
    private static final Logger logger = LoggerFactory.getLogger(OrchestratorTest.class);

    /**
     * , it should not throw exceptions
     */
    @Test
    public void mainTest() {
        // GIVEN
        String[] args = { getClass().getClassLoader().getResource("config/conf.json").getFile() };
        // WHEN
        Orchestrator.main(args);
        // THEN no exceptions
    }

    @Test
    public void mainTestLogException() {
        // GIVEN
        String[] args = { "" };
        // WHEN
        Orchestrator.main(args);
        // THEN no exceptions
    }
}
