package com.bnp.datahub.datagenerator.generator;

import org.junit.Assert;
import org.junit.Test;

import java.text.ParseException;

public class RandomDateTest {
    private static RandomDate randomDate;
    private static final String DATE_FORMAT = "yyyy-MM-dd";
    private static final int MAX_NUMBER_OF_DAYS = 17896;
    private static final long MAX_LONG_TIMESTAMP = 1546214400000L;


    /**
     *
     */
    @Test
    public void generateRandomDate() throws ParseException {
        //Given
        randomDate = new RandomDate(DATE_FORMAT, true);

        //When
        int nbDays = randomDate.nextDate();

        //Then
        Assert.assertTrue((MAX_NUMBER_OF_DAYS >= nbDays) && (nbDays >= 0));
    }

    /**
     *
     */
    @Test(expected = ParseException.class)
    public void generateRandomDateException() throws ParseException {
        //Given
        randomDate = new RandomDate("yyyy/MM/dd", true);

        //When
        randomDate.nextDate();

        //Then
        Assert.fail("A ParseException should be thrown");
    }

    /**
     *
     */
    @Test
    public void generateRandomTimestamp() throws ParseException {
        //Given
        randomDate = new RandomDate(DATE_FORMAT, true);

        //When
        long timestamp = randomDate.nextTimestamp();

        //Then
        Assert.assertTrue((MAX_LONG_TIMESTAMP >= timestamp) && (timestamp >= 0));
    }
}
