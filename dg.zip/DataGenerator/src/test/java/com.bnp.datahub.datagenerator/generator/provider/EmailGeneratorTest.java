package com.bnp.datahub.datagenerator.generator.provider;

import com.bnp.datahub.datagenerator.context.ExecutionContext;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

import static com.bnp.datahub.datagenerator.utils.Const.DICTIONARY_LAST_NAME_DAT;
import static com.bnp.datahub.datagenerator.utils.Const.DICTIONARY_FEMALE_FIRST_NAME_DAT;
import static com.bnp.datahub.datagenerator.utils.Const.DICTIONARY_MALE_FIRST_NAME_DAT;
import static com.bnp.datahub.datagenerator.utils.Const.COMMA;
import static com.bnp.datahub.datagenerator.utils.Const.DOMAIN;


public class EmailGeneratorTest {
    public static final ExecutionContext CONTEXT = new ExecutionContext();
    private EmailGenerator emailGenerator = new EmailGenerator();
    private List<String> listLastNames;
    private List<String> listFemaleNames;
    private List<String> listMaleNames;

    @Before
    public void setUp() throws IOException {
        emailGenerator.init(CONTEXT, null);
        InputStream lastNameStream = PeopleNameGenerator.class.getClassLoader().getResourceAsStream(DICTIONARY_LAST_NAME_DAT);
        InputStream femaleNameStream = PeopleNameGenerator.class.getClassLoader().getResourceAsStream(DICTIONARY_FEMALE_FIRST_NAME_DAT);
        InputStream maleNameStream = PeopleNameGenerator.class.getClassLoader().getResourceAsStream(DICTIONARY_MALE_FIRST_NAME_DAT);

        String lastNamesStr = IOUtils.toString(lastNameStream);
        String femaleNamesStr = IOUtils.toString(femaleNameStream);
        String maleNamesStr = IOUtils.toString(maleNameStream);

        listLastNames = Arrays.asList(lastNamesStr.split(COMMA));
        listFemaleNames = Arrays.asList(femaleNamesStr.split(COMMA));
        listMaleNames = Arrays.asList(maleNamesStr.split(COMMA));
    }

    @Test
    public void generateEmailDomainTest() {
        // GIVEN
        //WHEN
        String email = emailGenerator.nextValue(StringUtils.EMPTY, StringUtils.EMPTY);
        // THEN
        String [] listEmail = email.split("@");
        String domain = listEmail[1];
        Assert.assertEquals(domain, DOMAIN);
    }


    @Test
    public void generateEmailFirstNameTest() {
        // GIVEN
        //WHEN
        String email = emailGenerator.nextValue(StringUtils.EMPTY, StringUtils.EMPTY);
        // THEN
        String [] listEmail = email.split("@");
        String fullName = listEmail[0];
        String firstName = fullName.split("\\.")[0];

        Assert.assertTrue(listFemaleNames.contains(firstName) || listMaleNames.contains(firstName));
    }


    @Test
    public void generateEmailLastNameTest() {
        // GIVEN
        //WHEN
        String email = emailGenerator.nextValue(StringUtils.EMPTY, StringUtils.EMPTY);
        // THEN
        String [] listEmail = email.split("@");
        String fullName = listEmail[0];
        String lastName = fullName.split("\\.")[1];

        Assert.assertTrue(listLastNames.contains(lastName));
    }
}
