/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.generator.provider;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Test;

import static com.bnp.datahub.datagenerator.utils.Const.PHONE_REGEX;

public class PhoneGeneratorTest {

    private PhoneGenerator phoneGenerator = new PhoneGenerator();

    @Test
    public void testNextValuePhone() {
        String phoneNumber = phoneGenerator.nextValue(StringUtils.EMPTY, StringUtils.EMPTY);
        Assert.assertTrue(phoneNumber.matches(PHONE_REGEX));
    }
}

