/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.parser;

import com.bnp.datahub.datagenerator.model.Config;
import com.bnp.datahub.datagenerator.testUtil.Util;
import org.junit.Assert;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

public class ConfParserTest {
    private ConfParser confParser = new ConfParser();

    /**
     * Test deserialize method. It should return a list of one Config element
     */
    @Test
    public void deserializeSizeTest() throws URISyntaxException, IOException {
        // Given
        File file = Util.getResource("config/conf.json");
        // When
        List<Config> list = confParser.deserialize(file);
        // Then
        Assert.assertEquals(1, list.size());
    }


    /**
     * Test deserialize method. It tests the number of lines value
     */
    @Test
    public void deserializeValueTest() throws URISyntaxException, IOException {
        // Given
        File file = Util.getResource("config/conf.json");
        // When
        List<Config> list = confParser.deserialize(file);
        // Then
        Assert.assertEquals(150, list.get(0).getCsvProps().getNumberOfLines());
    }
}
