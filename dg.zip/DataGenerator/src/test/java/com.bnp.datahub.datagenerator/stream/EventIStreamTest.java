/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.stream;

import com.bnp.datahub.datagenerator.generator.EventGenerator;
import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class EventIStreamTest {
    private static final int MAX_EVENTS = 1;
    private EventStream eventStream;
    private Schema schema = SchemaBuilder.record("test").fields()
            .name("nom")
            .type("string")
            .withDefault(StringUtils.EMPTY)
            .endRecord();
    private GenericRecord genericRecord = new GenericData.Record(schema);

    @Before
    public void setUp(){
        EventGenerator eventGeneratorMock = mock(EventGenerator.class);
        when(eventGeneratorMock.generate()).thenReturn(genericRecord);
        eventStream = new EventStream(eventGeneratorMock);
    }

    @Test
    public void getEventTest(){
        // GIVEN
        // WHEN
        GenericRecord actual = this.eventStream.getEvent().limit(MAX_EVENTS).findFirst().get();
        // THEN
        assertThat(actual, is(genericRecord));
    }
}
