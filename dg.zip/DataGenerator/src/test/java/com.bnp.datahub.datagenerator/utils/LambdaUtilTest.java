/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.utils;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class LambdaUtilTest {

    private String[] exampleList = new String[]{
            "item1",
            "item2"
    };

    private String[] reverseExampleList = new String[]{
            "1meti",
            "2meti"
    };

    /**
     * , it should not throw an exception
     */
    @Test
    public void throwingConsumerWrapperTest() {
        // GIVEN
        List<StringBuffer> stringList = Arrays.asList(exampleList).stream().map(StringBuffer::new).collect(Collectors.toList());
        // WHEN
        stringList.stream().forEach(LambdaUtil.throwingConsumerWrapper(StringBuffer::reverse));
        // THEN
        assertThat(stringList.stream().map(StringBuffer::toString).collect(Collectors.toList()), is(Arrays.asList(reverseExampleList)));
    }

    /**
     * , it should thro a runtime exception
     */
    @Test(expected = RuntimeException.class)
    public void throwingConsumerWrapperTestThrowException() {
        // GIVEN
        List<StringBuffer> stringList = Arrays.asList(new StringBuffer(), null);
        // WHEN
        stringList.stream().forEach(LambdaUtil.throwingConsumerWrapper(StringBuffer::reverse));
        // THEN exception thrown
    }
}
