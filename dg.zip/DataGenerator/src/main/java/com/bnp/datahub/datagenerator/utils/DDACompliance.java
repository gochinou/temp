/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.utils;


import com.bnp.datahub.datagenerator.context.ExecutionContext;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.Schema;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static net.logstash.logback.marker.Markers.append;

public class DDACompliance {
    private static final String ROOT_CORRELATION_ID = "rootCorrelationId";
    private static final String PARENT_CORRELATION_ID = "parentCorrelationId";
    private static final String CORRELATION_ID = "correlationId";

    public static Schema addCorrelationIds(Schema schema) {
        Schema recordSchema = schema;
        Optional<String> rootCorrelationId = schema.getFields().stream().map(Schema.Field::name)
                .filter(name -> ROOT_CORRELATION_ID.equals(name)).findFirst();
        Optional<String> parentCorrelationId = schema.getFields().stream().map(Schema.Field::name)
                .filter(name -> PARENT_CORRELATION_ID.equals(name)).findFirst();
        if (!rootCorrelationId.isPresent() || !parentCorrelationId.isPresent()) {
            recordSchema = Schema.createRecord(schema.getName(), schema.getDoc(), schema.getNamespace(), schema.isError());
            List<Schema.Field> fields = schema.getFields();
            List<Schema.Field> newfields = fields.stream().map(field -> new Schema.Field(field.name(), field.schema(), field.doc(), field.defaultVal())).collect(Collectors.toList());
            if (!rootCorrelationId.isPresent()) {
                addCorrelationId(newfields, ROOT_CORRELATION_ID);
            }
            if (!parentCorrelationId.isPresent()) {
                addCorrelationId(newfields, PARENT_CORRELATION_ID);
            }
            recordSchema.setFields(newfields);
        }
        return recordSchema;
    }

    private static void addCorrelationId(List<Schema.Field> newfields, String fieldName) {
        Schema.Field rootCorrelationIdField = createCorrelationField(fieldName);
        newfields.add(rootCorrelationIdField);
    }


    private static Schema.Field createCorrelationField(String fieldName) {
        Schema stringSchema = Schema.create(Schema.Type.STRING);
        return new Schema.Field(fieldName, stringSchema, Const.CORRELATIONID, StringUtils.EMPTY);
    }

    public static LogstashMarker getCorrelationIdsMarkersFromContext(ExecutionContext context) {
        return append(ROOT_CORRELATION_ID, context.getRootCorrelationId()).and(append(PARENT_CORRELATION_ID, context.getParentCorrelationId())).and(append(CORRELATION_ID, context.getCorrelationId()));
    }
}
