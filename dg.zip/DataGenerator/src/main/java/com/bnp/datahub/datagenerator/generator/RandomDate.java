/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.generator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;


public class RandomDate {
    private static final int MILLIS_TO_DAYS = 86400000;
    private static final String TIME_ZONE_GMT = "GMT";
    private static final String DATE_SEPARATOR = "-";
    private DateFormat formatter;
    private static SecureRandom random = new SecureRandom();

    /**
     * The constructor of the RandomDate
     * @param format the date format. Example: yyyy-MM-dd
     * @param isGMT boolean that tells if it is GMT ot not
     */
    public RandomDate (String format, Boolean isGMT) {
        formatter = new SimpleDateFormat(format);
        if (isGMT) formatter.setTimeZone(TimeZone.getTimeZone(TIME_ZONE_GMT));
        formatter.setLenient(false);
    }


    /**
     * This method generates a random date since 1970
     * @return the number of days from 1970 to the generated random date
     */
    public int nextDate() throws ParseException {
        Date date;
        int numberOfDays;
        int year = randBetween(1970, 2018);
        int month = randBetween(1, 12);
        int day = (month == 2) ?  randBetween(1, 28) : randBetween(1, 31);

        String randomDate  =  Integer.toString(year) + DATE_SEPARATOR + Integer.toString(month) + DATE_SEPARATOR + Integer.toString(day);

        date = formatter.parse(randomDate);
        numberOfDays = (int) (date.getTime() / MILLIS_TO_DAYS);

        return numberOfDays;
    }

    /**
     * This method generates a random timestamp
     * @return timestamp as a long number
     */
    public long nextTimestamp() throws ParseException {
        Date date;
        long timestamp;
        int year = randBetween(1970, 2018);
        int month = randBetween(1, 12);
        int day = (month == 2) ?  randBetween(1, 28) : randBetween(1, 31);

        String randomDate  =  Integer.toString(year) + DATE_SEPARATOR + Integer.toString(month) + DATE_SEPARATOR + Integer.toString(day);

        date = formatter.parse(randomDate);
        timestamp = date.getTime();

        return timestamp;
    }

    /**
     * This method generates random int between two given numbers
     * @param start the from number
     * @param end the end number
     * @return random number
     */
    private static int randBetween(int start, int end) {
        return start + random.nextInt(end - start);
    }
}