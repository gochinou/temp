/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CsvProps {
    private String targetDir;
    private String fileName;
    private String archiveName;
    private int numberOfLines;
    private int numberOfFiles;
    private CsvOptions csvOptions;
    private boolean withHeader;
    private boolean withArchive;

    public String getFileName() {
        return fileName;
    }

    public String getArchiveName() {
        return archiveName;
    }

    public String getTargetDir() {
        return targetDir;
    }

    public int getNumberOfLines() {
        return numberOfLines;
    }

    public int getNumberOfFiles() {
        return numberOfFiles;
    }

    public CsvOptions getCsvOptions() {
        return csvOptions;
    }

    public boolean isWithHeader() {
        return withHeader;
    }

    public boolean isWithArchive() {
        return withArchive;
    }
}
