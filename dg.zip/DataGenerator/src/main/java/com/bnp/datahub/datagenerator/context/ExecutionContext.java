/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.context;

import java.util.HashMap;
import java.util.Map;

public class ExecutionContext {
    private String correlationId;
    private String parentCorrelationId;
    private String rootCorrelationId;

    private Map<String, Object> properties = new HashMap<>();

    public void addProperty(String key, Object value){
        properties.put(key, value);
    }

    public Object getPropertyValue(String key){
        return properties.get(key);
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getParentCorrelationId() {
        return parentCorrelationId;
    }

    public void setParentCorrelationId(String parentCorrelationId) {
        this.parentCorrelationId = parentCorrelationId;
    }

    public String getRootCorrelationId() {
        return rootCorrelationId;
    }

    public void setRootCorrelationId(String rootCorrelationId) {
        this.rootCorrelationId = rootCorrelationId;
    }
}
