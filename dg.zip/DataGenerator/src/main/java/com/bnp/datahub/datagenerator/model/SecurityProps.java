/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SecurityProps {
    private String sslTrustStoreLocation;
    private String sslKeyStoreLocation;
    private String sslTrustStorePassword;
    private String sslKeyStorePassword;
    private String sslKeyPassword;
    private String sslSRKeyStoreLocation;
    private String sslSRKeyStorePassword;

    public String getSslTrustStoreLocation() {
        return sslTrustStoreLocation;
    }

    public String getSslKeyStoreLocation() {
        return sslKeyStoreLocation;
    }

    public String getSslTrustStorePassword() {
        return sslTrustStorePassword;
    }

    public String getSslKeyStorePassword() {
        return sslKeyStorePassword;
    }

    public String getSslKeyPassword() {
        return sslKeyPassword;
    }

    public String getSslSRKeyStoreLocation() {
        return sslSRKeyStoreLocation;
    }

    public String getSslSRKeyStorePassword() {
        return sslSRKeyStorePassword;
    }
}
