/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.apache.avro.Schema;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Config {

    private String output;
    private int naughtyStringsPerc;
    private KafkaProps kafkaProps;
    private CsvProps csvProps;
    private Schema schemaAvro;
    private String rootCorrelationId;
    private String parentCorrelationId;


    public int getNaughtyStringsPerc() { return naughtyStringsPerc; }

    public String getOutput() {
        return output;
    }

    public KafkaProps getKafkaProps() {
        return kafkaProps;
    }

    public CsvProps getCsvProps() {
        return csvProps;
    }

    public Schema getSchemaAvro() {
        return schemaAvro;
    }

    public String getRootCorrelationId() {
        return rootCorrelationId;
    }

    public String getParentCorrelationId() {
        return parentCorrelationId;
    }
}
