/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.generator.provider;

import com.bnp.datahub.datagenerator.context.ExecutionContext;
import com.fasterxml.uuid.Generators;
import com.fasterxml.uuid.impl.TimeBasedGenerator;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.security.SecureRandom;
import java.util.Map;
import java.util.UUID;

import static com.bnp.datahub.datagenerator.utils.Const.COMMA;
import static com.bnp.datahub.datagenerator.utils.Const.DICTIONARY_CITIES_DAT;

public class CorrelationIdGenerator implements Generator {

    private static final TimeBasedGenerator TIME_BASED_GENERATOR = Generators.timeBasedGenerator();
    private static final String PARENT_CORRELATION_ID = "parentCorrelationId";
    private static final String ROOT_CORRELATION_ID = "rootCorrelationId";

    private String parentCorrelationId;
    private String rootCorrelationId;

    @Override
    public void init(ExecutionContext context, Map<String, String> props) {
        parentCorrelationId = context.getCorrelationId();
        rootCorrelationId = context.getRootCorrelationId();
    }

    @Override
    public String nextValue(String familyName, String fieldName) {
        switch (fieldName){
            case PARENT_CORRELATION_ID :
                return parentCorrelationId != null ? parentCorrelationId : TIME_BASED_GENERATOR.generate().toString();
            case ROOT_CORRELATION_ID :
                return rootCorrelationId != null ? rootCorrelationId : TIME_BASED_GENERATOR.generate().toString();
            default :
                return TIME_BASED_GENERATOR.generate().toString();
        }
    }
}
