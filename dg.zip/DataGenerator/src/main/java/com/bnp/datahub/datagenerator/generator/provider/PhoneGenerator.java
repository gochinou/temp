/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.generator.provider;

import com.bnp.datahub.datagenerator.context.ExecutionContext;

import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Map;

import static com.bnp.datahub.datagenerator.utils.Const.PHONE_CONST;
import static com.bnp.datahub.datagenerator.utils.Const.PHONE_FORMAT;

public class PhoneGenerator implements Generator {
    private SecureRandom secureRandom = new SecureRandom();

    @Override
    public void init(ExecutionContext context, Map<String, String> props) {

    }

    @Override
    public String nextValue(String familyName, String fieldName) {
        return String.format(PHONE_FORMAT,
                Arrays.asList(6, 7).get(secureRandom.nextInt(2)),
                (int) Math.floor(PHONE_CONST * secureRandom.nextDouble()));
    }
}
