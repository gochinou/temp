/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.parser;

import com.bnp.datahub.datagenerator.model.Config;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import org.apache.avro.Schema;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class ConfParser {

    private ObjectMapper objectMapper;

    public ConfParser() {
        objectMapper = new ObjectMapper();
        SimpleModule module = new SimpleModule();
        module.addDeserializer(Schema.class, new SchemaDeserializer());
        objectMapper.registerModule(module);
    }

    public List<Config> deserialize(File file) throws IOException {
        return objectMapper.readValue(file, new TypeReference<List<Config>>() {
        });
    }

    public Config deserialize(String json) throws IOException {
        return objectMapper.readValue(json, Config.class);
    }
}
