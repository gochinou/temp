/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.generator.provider;

import com.bnp.datahub.datagenerator.context.ExecutionContext;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import com.typesafe.config.ConfigList;
import com.typesafe.config.ConfigValue;
import org.apache.avro.Schema;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.bnp.datahub.datagenerator.utils.Const.*;

public class GeneratorFactory {
    private static final Config config = ConfigFactory.load(FAMILIES_CONF);
    private static final Map<String, String> fieldsFamiliesCache = new HashMap<>();
    private Map<String, Generator> generators = new HashMap<>();

    private RandomStringsGenerator randomeStringGenerator;

    public GeneratorFactory(ExecutionContext context){
        initPeopleLastNameGenerator(context);
        initPeopleFirstNameGenerator(context);
        initCityGenerator(context);
        initEmailGenerator(context);
        initNaughtyGenerator(context);
        initPhoneGenerator(context);
        initCorrelationIdGenerator(context);
    }

    private void initPeopleLastNameGenerator(ExecutionContext context){
        Map<String, String> props = new HashMap<>();
        Generator peopleLastNameGenerator = new PeopleNameGenerator();
        props.put(TYPE, LAST);
        props.put(GENDER, ALL);
        peopleLastNameGenerator.init(context, props);
        generators.put(LAST_NAME, peopleLastNameGenerator);
    }

    private void initPeopleFirstNameGenerator(ExecutionContext context){
        Map<String, String> props = new HashMap<>();
        Generator peopleFirstNameGenerator = new PeopleNameGenerator();
        props.put(TYPE, FIRST);
        props.put(GENDER, ALL);
        peopleFirstNameGenerator.init(context, props);
        generators.put(FIRST_NAME, peopleFirstNameGenerator);
    }

    private void initEmailGenerator(ExecutionContext context){
        Generator emailGenerator = new EmailGenerator();
        emailGenerator.init(context, null);
        generators.put(EMAIL, emailGenerator);
    }

    private void initPhoneGenerator(ExecutionContext context){
        Generator phoneGenerator = new PhoneGenerator();
        phoneGenerator.init(context, null);
        generators.put(PHONE, phoneGenerator);
    }

    private void initCityGenerator(ExecutionContext context){
        Generator cityGenerator = new CityGenerator();
        cityGenerator.init(context, null);
        generators.put(CITY, cityGenerator);
    }

    private void initNaughtyGenerator(ExecutionContext context){
        randomeStringGenerator = new RandomStringsGenerator();
        randomeStringGenerator.init(context, null);
    }

    private void initCorrelationIdGenerator(ExecutionContext context){
        Generator correlationIdGenerator = new CorrelationIdGenerator();
        correlationIdGenerator.init(context, null);
        generators.put(CORRELATIONID, correlationIdGenerator );
    }

    public String generateField(Schema.Field field) {
        String fieldDoc = field.doc();
        if (fieldDoc != null) {
            String fieldFamily = getAndStoreFieldFamily(fieldDoc);
            Generator generator = generators.get(fieldFamily);
            String fieldName = field.name();
            if(generator != null){
                return generator.nextValue(fieldFamily, fieldName);
            }else{
                return randomeStringGenerator.nextValue(fieldFamily, fieldName);
            }
        } else return randomeStringGenerator.nextValue(StringUtils.EMPTY, StringUtils.EMPTY);
    }

    private String getAndStoreFieldFamily(String name) {
        String cachedFieldFamily = fieldsFamiliesCache.get(name);
        if (cachedFieldFamily == null) {
            cachedFieldFamily = config.getConfig(FAMILIES).entrySet().stream().filter(entry -> {
                ConfigList namesConfigList = (ConfigList) entry.getValue();
                List<String> names = namesConfigList.stream()
                        .map(ConfigValue::unwrapped)
                        .map(Object::toString)
                        .map(String::toLowerCase)
                        .collect(Collectors.toList());
                return names.contains(name.toLowerCase());
            }).findFirst().map(Map.Entry::getKey).orElse(StringUtils.EMPTY);
            fieldsFamiliesCache.put(name, cachedFieldFamily);
        }
        return cachedFieldFamily;
    }
}
