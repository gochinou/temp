/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.sink;

import com.bnp.datahub.datagenerator.context.ExecutionContext;
import com.bnp.datahub.datagenerator.model.Config;
import com.bnp.datahub.datagenerator.utils.DDACompliance;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import io.confluent.kafka.serializers.KafkaAvroSerializerConfig;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

import static com.bnp.datahub.datagenerator.utils.Const.JAVAX_NET_SSL_TRUST_STORE_PASS;
import static com.bnp.datahub.datagenerator.utils.Const.JAVAX_NET_SSL_KEY_STORE;
import static com.bnp.datahub.datagenerator.utils.Const.JAVAX_NET_SSL_TRUST_STORE;
import static com.bnp.datahub.datagenerator.utils.Const.JAVAX_NET_SSL_KEY_STORE_PASS;
import static com.bnp.datahub.datagenerator.utils.Const.SSL;

public class KafkaSink implements Sink {

    private static final Logger logger = LoggerFactory.getLogger(KafkaSink.class);

    private KafkaProducer<String, GenericRecord> kafkaProducer;
    private Config config;
    private LogstashMarker correlationIds;

    /**
     * Initialize the Kafka configuration
     *
     * @param config config file
     */
    @Override
    public void init(ExecutionContext context, Config config) {
        logger.debug("Initialize the kafka configuration ...");
        Properties properties = new Properties();
        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, config.getKafkaProps().getBootstrapServers());
        properties.put(KafkaAvroSerializerConfig.SCHEMA_REGISTRY_URL_CONFIG, config.getKafkaProps().getSchemaRegistry());
        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class);
        if (config.getKafkaProps().isWithSSL()) {
            properties.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, SSL);
            properties.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, config.getKafkaProps().getSecurityProps().getSslTrustStoreLocation());
            properties.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, config.getKafkaProps().getSecurityProps().getSslTrustStorePassword());
            properties.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, config.getKafkaProps().getSecurityProps().getSslKeyStoreLocation());
            properties.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, config.getKafkaProps().getSecurityProps().getSslKeyStorePassword());
            properties.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, config.getKafkaProps().getSecurityProps().getSslKeyPassword());
            System.setProperty(JAVAX_NET_SSL_TRUST_STORE, config.getKafkaProps().getSecurityProps().getSslTrustStoreLocation());
            System.setProperty(JAVAX_NET_SSL_TRUST_STORE_PASS, config.getKafkaProps().getSecurityProps().getSslTrustStorePassword());
            System.setProperty(JAVAX_NET_SSL_KEY_STORE, config.getKafkaProps().getSecurityProps().getSslSRKeyStoreLocation());
            System.setProperty(JAVAX_NET_SSL_KEY_STORE_PASS, config.getKafkaProps().getSecurityProps().getSslSRKeyStorePassword());
        }
        kafkaProducer = new KafkaProducer<>(properties);
        this.config = config;
        this.correlationIds = DDACompliance.getCorrelationIdsMarkersFromContext(context);
    }

    /**
     * Writes a random record into Kafka
     *
     * @param record the record to write in Kafka
     */
    @Override
    public void process(GenericRecord record) {
        logger.debug(correlationIds, "Send the record to Kafka ...");
        String topicName = config.getKafkaProps().getTopicName();
        kafkaProducer.send(new ProducerRecord<>(topicName, null, record), ((RecordMetadata metadata, Exception exception) -> {
                    if (exception != null) {
                        logger.error(correlationIds, exception.getMessage());
                    } else {
                        logger.debug(correlationIds,"Record was written in kafka in the offset {}", metadata.offset());
                    }
                })
        );
    }

    /**
     * close the kafka producer
     */
    @Override
    public void close() {
        kafkaProducer.close();
        logger.debug(correlationIds,"The kafka producer is correctly closed!");
    }
}