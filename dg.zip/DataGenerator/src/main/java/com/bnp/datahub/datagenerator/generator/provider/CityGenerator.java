/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.generator.provider;

import com.bnp.datahub.datagenerator.context.ExecutionContext;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.security.SecureRandom;
import java.util.Map;

import static com.bnp.datahub.datagenerator.utils.Const.COMMA;
import static com.bnp.datahub.datagenerator.utils.Const.DICTIONARY_CITIES_DAT;

public class CityGenerator implements Generator {
    private static String[] CITIES;

    private SecureRandom random = new SecureRandom();

    private synchronized static void initCities() {
        if (CITIES == null) {
            try (InputStream citiesStream = CityGenerator.class.getClassLoader()
                    .getResourceAsStream(DICTIONARY_CITIES_DAT)) {
                String namesStr = IOUtils.toString(citiesStream);
                CITIES = namesStr.split(COMMA);
            } catch (IOException e) {
                throw new RuntimeException("Failed to load cities", e);
            }
        }
    }

    private String getRandomCity() {
        initCities();
        int index = random.nextInt(CITIES.length);
        return CITIES[index];
    }

    @Override
    public void init(ExecutionContext context, Map<String, String> props) {
    }

    @Override
    public String nextValue(String familyName, String fieldName) {
        return getRandomCity();
    }
}
