/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.main;

import com.bnp.datahub.datagenerator.context.ExecutionContext;
import com.bnp.datahub.datagenerator.generator.EventGenerator;
import com.bnp.datahub.datagenerator.generator.provider.CorrelationIdGenerator;
import com.bnp.datahub.datagenerator.model.Config;
import com.bnp.datahub.datagenerator.sink.ArchiveSink;
import com.bnp.datahub.datagenerator.sink.CsvSink;
import com.bnp.datahub.datagenerator.sink.KafkaSink;
import com.bnp.datahub.datagenerator.stream.EventStream;
import com.bnp.datahub.datagenerator.utils.DDACompliance;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.Schema;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.security.SecureRandom;

import static com.bnp.datahub.datagenerator.utils.Const.CSV;
import static com.bnp.datahub.datagenerator.utils.Const.KAFKA;
import static com.bnp.datahub.datagenerator.utils.Const.RANDOM_PROPERTY;
import static com.bnp.datahub.datagenerator.utils.Const.NAUGHTY_STRINGS_PERC_PROPERTY;

import static com.bnp.datahub.datagenerator.utils.LambdaUtil.throwingConsumerWrapper;

public class Core {

    private static final Logger logger = LoggerFactory.getLogger(Core.class);
    private static final CorrelationIdGenerator CORRELATION_ID_GENERATOR = new CorrelationIdGenerator();

    public static void process(Config conf) throws IOException {
        Schema schema = conf.getSchemaAvro();
        ExecutionContext context = getExecutionContext(conf);

        EventGenerator eventGenerator = new EventGenerator(context, schema);

        EventStream eventStream = new EventStream(eventGenerator);
        LogstashMarker correlationIds = DDACompliance.getCorrelationIdsMarkersFromContext(context);

        if (conf.getOutput().equals(CSV)) {
            CsvSink csvSink = new CsvSink();

            logger.info(correlationIds,"Start Generating lines in csv files");
            logger.info(correlationIds, "Number of files : {}", conf.getCsvProps().getNumberOfFiles());
            logger.info(correlationIds, "Number of lines per file : {}", conf.getCsvProps().getNumberOfLines());
            csvSink.init(context, conf);
            for (int i = 0; i < conf.getCsvProps().getNumberOfFiles(); i++) {
                csvSink.createFile(i);
                if (conf.getCsvProps().isWithHeader()) csvSink.writeHeader(eventGenerator.generate());
                eventStream.getEvent().limit(conf.getCsvProps().getNumberOfLines()).forEach(throwingConsumerWrapper(csvSink::process));
                csvSink.close();
            }
            logger.info(correlationIds, "End Generating lines in csv files");
            if (conf.getCsvProps().isWithArchive()) {
                ArchiveSink archiveSink = new ArchiveSink(context);
                archiveSink.compressFiles(csvSink.getDirectory(), csvSink.getTmpDirectory(), conf.getCsvProps().getArchiveName());
            } else {
                csvSink.moveFilesToTarget();
            }
        } else if (conf.getOutput().equals(KAFKA)) {
            KafkaSink kafkaSink = new KafkaSink();
            kafkaSink.init(context, conf);
            logger.info(correlationIds, "Start Generating events in Kafka");
            logger.info(correlationIds, "Number of events : {}", conf.getKafkaProps().getNumberOfEvents());
            eventStream.getEvent().limit(conf.getKafkaProps().getNumberOfEvents()).forEach(kafkaSink::process);
            kafkaSink.close();
            logger.info(correlationIds, "End Generating events in Kafka");
        }
    }



    private static ExecutionContext getExecutionContext(Config conf) {
        String rootCorrelationId = conf.getRootCorrelationId();
        String parentCorrelationId = conf.getParentCorrelationId();
        String correlationId;
        if (conf.getCsvProps() != null){
            correlationId = conf.getCsvProps().getFileName() + "-" + System.currentTimeMillis();
        }
        else{
            correlationId = StringUtils.EMPTY + System.currentTimeMillis();
        }

        if (StringUtils.isEmpty(rootCorrelationId)){
            rootCorrelationId = correlationId;
        }
        if (StringUtils.isEmpty(parentCorrelationId)){
            parentCorrelationId = correlationId;
        }

        ExecutionContext context = new ExecutionContext();
        context.setCorrelationId(correlationId);
        context.setParentCorrelationId(parentCorrelationId);
        context.setRootCorrelationId(rootCorrelationId);

        SecureRandom random = new SecureRandom();
        int naughtyStringsPerc = conf.getNaughtyStringsPerc();

        context.addProperty(RANDOM_PROPERTY, random);
        context.addProperty(NAUGHTY_STRINGS_PERC_PROPERTY, naughtyStringsPerc);

        return context;
    }
}
