/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.sink;


import com.bnp.datahub.datagenerator.context.ExecutionContext;
import com.bnp.datahub.datagenerator.utils.DDACompliance;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import static com.bnp.datahub.datagenerator.utils.Const.ARCHIVE_EXT;

public class ArchiveSink {
    private static final Logger logger = LoggerFactory.getLogger(ArchiveSink.class);
    private LogstashMarker correlationIds;

    public ArchiveSink(ExecutionContext context){
        correlationIds = DDACompliance.getCorrelationIdsMarkersFromContext(context);
    }

    public void compressFiles(File targetDirectory, File tmpDirectory, String archiveName) throws IOException {
        String archivePathNameHidden = targetDirectory.getAbsolutePath() + File.separator + "." + archiveName + ARCHIVE_EXT;
        String archivePathName = targetDirectory.getAbsolutePath() + File.separator + archiveName + ARCHIVE_EXT;
        compress(archivePathNameHidden, tmpDirectory.listFiles());
        File archiveFile = new File(archivePathName);
        if (archiveFile.exists()) {
            if(archiveFile.delete()){
                logger.info(correlationIds, "File {} was deleted", archivePathName);
            }else{
                logger.warn(correlationIds,"Unable to delete file {}", archivePathName);
            }
        }
        FileUtils.moveFile(new File(archivePathNameHidden), archiveFile);
        FileUtils.deleteDirectory(tmpDirectory);
        logger.info(correlationIds,"Archive Created {}", archivePathName);
    }

    private void compress(String name, File... files) throws IOException {
        try (TarArchiveOutputStream out = getTarArchiveOutputStream(name)) {
            for (File file : files) {
                addToArchiveCompression(out, file, ".");
            }
        }
    }

    private TarArchiveOutputStream getTarArchiveOutputStream(String name) throws IOException {
        TarArchiveOutputStream tarArchiveOutputStream = new TarArchiveOutputStream(new GzipCompressorOutputStream(new FileOutputStream(name)));
        tarArchiveOutputStream.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_STAR);
        tarArchiveOutputStream.setLongFileMode(TarArchiveOutputStream.LONGFILE_GNU);
        tarArchiveOutputStream.setAddPaxHeadersForNonAsciiNames(true);
        return tarArchiveOutputStream;
    }

    private void addToArchiveCompression(TarArchiveOutputStream out, File file, String dir) throws IOException {
        String entry = dir + File.separator + file.getName();
        if (file.isFile()) {
            out.putArchiveEntry(new TarArchiveEntry(file, entry));
            try (FileInputStream in = new FileInputStream(file)) {
                IOUtils.copy(in, out);
            }
            out.closeArchiveEntry();
        } else if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    addToArchiveCompression(out, child, entry);
                }
            }
        } else {
            logger.info(correlationIds, file.getName() + " is not supported");
        }
    }
}
