/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.generator;

import com.bnp.datahub.datagenerator.context.ExecutionContext;
import com.bnp.datahub.datagenerator.generator.provider.GeneratorFactory;
import com.bnp.datahub.datagenerator.utils.DDACompliance;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.LogicalTypes;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.SecureRandom;
import java.text.ParseException;
import java.util.List;
import java.util.Random;

import static com.bnp.datahub.datagenerator.utils.Const.*;

public class EventGenerator {
    private static final Logger logger = LoggerFactory.getLogger(EventGenerator.class);

    private Schema schema;
    private GeneratorFactory generatorFactory;
    private Random random;
    private LogstashMarker correlationIds;

    /**
     * This function constructs the object EventGenerator using the given schema
     *
     * @param schema the schema to construct the EventGenerator with
     */
    public EventGenerator(ExecutionContext context, Schema schema){
        this.schema = schema;
        this.random =  (Random) context.getPropertyValue(RANDOM_PROPERTY);
        this.generatorFactory = new GeneratorFactory(context);
        correlationIds = DDACompliance.getCorrelationIdsMarkersFromContext(context);
        if(random == null){
            random = new SecureRandom();
            context.addProperty(RANDOM_PROPERTY, random);
        }
    }

    /**
     * This function generates a generic record with random data based on a schema
     */
    public GenericRecord generate() {

        List<Schema.Field> fields = schema.getFields();
        GenericRecord genericRecord = new GenericData.Record(schema);
        fields.forEach(field -> {
            try {
                putInRecord(genericRecord, field, field.schema().getType());
            } catch (ParseException e) {
                logger.error(correlationIds,e.getMessage());
            }
        });
        logger.debug(correlationIds, "The generated record is {}", genericRecord);

        return genericRecord;
    }

    /**
     * This function puts random data in a record by calling switchTypes function
     *
     * @param record the record where to write
     * @param field  the field to put in the record
     * @param type   the type to switch on to generate the random schemas
     */
    private void putInRecord(GenericRecord record, Schema.Field field, Schema.Type type) throws ParseException {

        if (type == Schema.Type.UNION) {
            switchTypes(record, field, field.schema().getTypes().get(random.nextInt(field.schema().getTypes().size())).getType());
        } else {
            switchTypes(record, field, type);
        }
    }

    /**
     * This function generates a random value depending on the type given in parameters
     * and puts it in a record
     *
     * @param record the record where to write
     * @param field  the field to put in the record
     * @param type   the type to switch on to generate the random schemas
     */
    private void switchTypes(GenericRecord record, Schema.Field field, Schema.Type type) throws ParseException {
        RandomDate randomDate = new RandomDate(DATE_FORMAT, true);

        switch (type) {
            case STRING:
                record.put(field.name(), generatorFactory.generateField(field));
                break;
            case INT:
                if (LogicalTypes.date().equals(field.schema().getLogicalType())) {
                    record.put(field.name(), randomDate.nextDate());
                } else {
                    record.put(field.name(), random.nextInt(100));
                }
                break;
            case LONG:
                if (LogicalTypes.timestampMillis().equals(field.schema().getLogicalType())) {
                    record.put(field.name(), randomDate.nextTimestamp());
                } else {
                    record.put(field.name(), random.nextLong());
                }
                break;
            case DOUBLE:
                record.put(field.name(), random.nextDouble());
                break;
            case BOOLEAN:
                record.put(field.name(), random.nextBoolean());
                break;
            case NULL:
                record.put(field.name(), null);
                break;
            case FLOAT:
                record.put(field.name(), random.nextFloat());
                break;
            case BYTES:
                byte[] newBytes = new byte[30];
                random.nextBytes(new byte[30]);
                int scale = (field.schema().getObjectProp(SCALE) == null) ? 0 : Integer.valueOf(field.schema().getObjectProp(SCALE).toString());
                int precision = (field.schema().getObjectProp(PRECISION) == null) ? -1 : Integer.valueOf(field.schema().getObjectProp(PRECISION).toString());

                if (field.schema().getObjectProp(PRECISION) != null && precision != -1) {
                    if (LogicalTypes.decimal(precision, scale).equals(field.schema().getLogicalType())) {
                        BigDecimal bigDecimal = BigDecimal.valueOf(random.nextDouble()).setScale(scale, RoundingMode.DOWN);
                        record.put(field.name(), bigDecimal);
                    }
                } else {
                    record.put(field.name(), newBytes);
                }
        }
    }
}