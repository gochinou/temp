/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.stream;


import com.bnp.datahub.datagenerator.generator.EventGenerator;
import org.apache.avro.generic.GenericRecord;

import java.util.Iterator;

public final class EventIterator implements Iterator<GenericRecord> {

    private EventGenerator eventGenerator;

    EventIterator(EventGenerator eventGenerator) {
        this.eventGenerator = eventGenerator;
    }

    @Override
    public boolean hasNext() {
        return true;
    }

    @Override
    public GenericRecord next() {
        return eventGenerator.generate();
    }
}
