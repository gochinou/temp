/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.generator.provider;

import com.bnp.datahub.datagenerator.context.ExecutionContext;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.RandomStringUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.security.SecureRandom;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.bnp.datahub.datagenerator.utils.Const.COUNT;
import static com.bnp.datahub.datagenerator.utils.Const.DEFAULT_NAUGHTY_STRINGS_PERC;
import static com.bnp.datahub.datagenerator.utils.Const.DICTIONARY_NAUGHTIES_DAT;
import static com.bnp.datahub.datagenerator.utils.Const.NAUGHTY_STRINGS_PERC_PROPERTY;


public class RandomStringsGenerator implements Generator {
    private static final int MAX_NAUGHTY_PERC = 100;
    private static String[] NAUGHTIES;


    private SecureRandom random = new SecureRandom();
    private int naughtyStringPerc;

    public RandomStringsGenerator(){
        this.naughtyStringPerc = DEFAULT_NAUGHTY_STRINGS_PERC;
    }

    private synchronized static void initNaughties() {
        if (NAUGHTIES == null) {
            try (InputStream naughtiesStream = CityGenerator.class.getClassLoader()
                    .getResourceAsStream(DICTIONARY_NAUGHTIES_DAT)) {
                List<String> naughties = IOUtils.readLines(naughtiesStream, Charset.defaultCharset());
                List<String> filtredNaughties = naughties.stream()
                        .filter((naughty) -> !naughty.isEmpty())
                        .filter((naughty) -> naughty.charAt(0) != '#')
                        .collect(Collectors.toList());
                NAUGHTIES = filtredNaughties.toArray(new String[filtredNaughties.size()]);
            } catch (IOException e) {
                throw new RuntimeException("Failed to load naughties", e);
            }
        }
    }

    private String getRandomNaughtyString(){
        initNaughties();
        int randomInt = random.nextInt(NAUGHTIES.length);
        return NAUGHTIES[randomInt];
    }

    @Override
    public void init(ExecutionContext context, Map<String, String> props) {
        Object naughtyValue = context.getPropertyValue(NAUGHTY_STRINGS_PERC_PROPERTY);
        if(naughtyValue != null){
            this.naughtyStringPerc = (Integer) naughtyValue;
        }
    }

    @Override
    public String nextValue(String familyName, String fieldName) {
        int naughtyPerc = random.nextInt(MAX_NAUGHTY_PERC);
        if(naughtyPerc < naughtyStringPerc){
            return getRandomNaughtyString();
        }
        return RandomStringUtils.randomAlphanumeric(COUNT);
    }
}
