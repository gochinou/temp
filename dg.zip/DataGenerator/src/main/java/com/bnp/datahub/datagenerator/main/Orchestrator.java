/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.main;

import com.bnp.datahub.datagenerator.model.Config;
import com.bnp.datahub.datagenerator.parser.ConfParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.util.List;

import static com.bnp.datahub.datagenerator.utils.LambdaUtil.throwingConsumerWrapper;

public class Orchestrator {
    private static final Logger logger = LoggerFactory.getLogger(Orchestrator.class);

    public static void main(String[] args) {
        try {
            ConfParser confParser = new ConfParser();
            List<Config> configList = confParser.deserialize(new File(args[0]));
            logger.debug("Start generating random data ...");
            configList.forEach(throwingConsumerWrapper(Core::process));
        } catch (IOException exception) {
            logger.error(exception.getMessage(), exception);
        }
    }
}
