/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.sink;

import com.bnp.datahub.datagenerator.context.ExecutionContext;
import com.bnp.datahub.datagenerator.model.Config;
import org.apache.avro.generic.GenericRecord;

import java.io.IOException;

public interface Sink {

    void init(ExecutionContext context, Config config) throws IOException;

    void process(GenericRecord record) throws IOException;

    void close() throws IOException;

}
