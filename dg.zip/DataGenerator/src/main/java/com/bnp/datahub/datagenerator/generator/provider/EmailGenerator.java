/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.generator.provider;

import com.bnp.datahub.datagenerator.context.ExecutionContext;

import java.util.HashMap;
import java.util.Map;

import static com.bnp.datahub.datagenerator.utils.Const.*;

public class EmailGenerator implements Generator {

    private PeopleNameGenerator lastNameProvider = new PeopleNameGenerator();
    private PeopleNameGenerator firstNameProvider = new PeopleNameGenerator();

    @Override
    public void init(ExecutionContext context, Map<String, String> props) {

        Map<String, String> lastNameProps = new HashMap<>();
        Map<String, String> firstNameProps = new HashMap<>();

        lastNameProps.put(TYPE, LAST);
        lastNameProps.put(GENDER, ALL);
        firstNameProps.put(TYPE, FIRST);
        firstNameProps.put(GENDER, ALL);

        lastNameProvider.init(context, lastNameProps);
        firstNameProvider.init(context, firstNameProps);
    }

    @Override
    public String nextValue(String familyName, String fieldName) {
        return firstNameProvider.nextValue(familyName, fieldName) + "." + lastNameProvider.nextValue(familyName, fieldName) + "@" + DOMAIN;

    }
}
