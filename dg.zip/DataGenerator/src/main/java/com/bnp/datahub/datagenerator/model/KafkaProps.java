/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class KafkaProps {
    private String bootstrapServers;
    private String schemaRegistry;
    private String topicName;
    private int numberOfEvents;
    private Boolean withSSL;
    private SecurityProps securityProps;

    public String getBootstrapServers() {
        return bootstrapServers;
    }

    public String getSchemaRegistry() {
        return schemaRegistry;
    }

    public String getTopicName() {
        return topicName;
    }

    public int getNumberOfEvents() {
        return numberOfEvents;
    }

    public Boolean isWithSSL() {
        return withSSL;
    }

    public SecurityProps getSecurityProps() {
        return securityProps;
    }
}
