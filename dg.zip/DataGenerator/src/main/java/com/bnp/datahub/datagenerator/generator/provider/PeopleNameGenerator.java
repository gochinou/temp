/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.generator.provider;

import com.bnp.datahub.datagenerator.context.ExecutionContext;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.security.SecureRandom;
import java.util.Map;

import static com.bnp.datahub.datagenerator.utils.Const.*;

public class PeopleNameGenerator implements Generator {
    private static String FAILED_TO_LOAD_NAMES_MESSAGE = "Failed to load names";

    private static String[] MALE_FIRST_NAMES;
    private static String[] FEMALE_FIRST_NAMES;
    private static String[] LAST_NAMES;

    private SecureRandom random = new SecureRandom();

    private boolean generateFirstName = true;
    private boolean generateLastName = true;
    private boolean generateMale = true;
    private boolean generateFemale = true;

    private synchronized static void initMaleNames(){
        if (MALE_FIRST_NAMES == null) {
            try (InputStream nameStream = PeopleNameGenerator.class.getClassLoader()
                    .getResourceAsStream(DICTIONARY_MALE_FIRST_NAME_DAT)) {
                String namesStr = IOUtils.toString(nameStream);
                MALE_FIRST_NAMES = namesStr.split(COMMA);
            } catch (IOException e) {
                throw new RuntimeException(FAILED_TO_LOAD_NAMES_MESSAGE, e);
            }
        }
    }

    private synchronized static void initFemaleNames(){
        if (FEMALE_FIRST_NAMES == null) {
            try (InputStream nameStream = PeopleNameGenerator.class.getClassLoader()
                    .getResourceAsStream(DICTIONARY_FEMALE_FIRST_NAME_DAT)) {
                String namesStr = IOUtils.toString(nameStream);
                FEMALE_FIRST_NAMES = namesStr.split(COMMA);
            } catch (IOException e) {
                throw new RuntimeException(FAILED_TO_LOAD_NAMES_MESSAGE, e);
            }
        }
    }

    private synchronized static void initLastNames(){
        if (LAST_NAMES == null) {
            try (InputStream nameStream = PeopleNameGenerator.class.getClassLoader()
                    .getResourceAsStream(DICTIONARY_LAST_NAME_DAT)) {
                String namesStr = IOUtils.toString(nameStream);
                LAST_NAMES = namesStr.split(COMMA);
            } catch (IOException e) {
                throw new RuntimeException(FAILED_TO_LOAD_NAMES_MESSAGE, e);
            }
        }
    }

    private String getRandomMaleName() {
        initMaleNames();
        int randomIndex = random.nextInt(MALE_FIRST_NAMES.length);
        return MALE_FIRST_NAMES[randomIndex];
    }

    private static int getMaleNamesLength(){
        initMaleNames();
        return MALE_FIRST_NAMES.length;
    }

    private String getRandomFemaleName() {
        initFemaleNames();
        int randomIndex = random.nextInt(FEMALE_FIRST_NAMES.length);
        return FEMALE_FIRST_NAMES[randomIndex];
    }

    private static int getFemaleNamesLength(){
        initFemaleNames();
        return FEMALE_FIRST_NAMES.length;
    }

    private String getRandomLastName() {
        initLastNames();
        int randomIndex = random.nextInt(LAST_NAMES.length);
        return LAST_NAMES[randomIndex];
    }

    @Override
    public void init(ExecutionContext context, Map<String, String> props) {
        String gender = props.get(GENDER);
        if (gender == null) {
            gender = ALL;
        }
        switch (gender) {
            case ALL:
                generateMale = true;
                generateFemale = true;
                break;
            case MALE:
                generateMale = true;
                generateFemale = false;
                break;
            case FEMALE:
                generateMale = false;
                generateFemale = true;
                break;
            default:
                throw new IllegalArgumentException("Unknown gender: " + gender);
        }
        String type = props.get(TYPE);
        if (type == null) {
            type = ALL;
        }
        switch (type) {
            case ALL:
                generateFirstName = true;
                generateLastName = true;
                break;
            case FIRST:
                generateFirstName = true;
                generateLastName = false;
                break;
            case LAST:
                generateFirstName = false;
                generateLastName = true;
                break;
            default:
                throw new IllegalArgumentException("Unknown name type: " + gender);
        }
    }

    @Override
    public String nextValue(String familyName, String fieldName) {
        String result = "";
        if (generateFirstName) {
            String firstName;
            if (generateMale && generateFemale) {
                int index = random.nextInt(getMaleNamesLength() + getFemaleNamesLength());
                if (index < getMaleNamesLength()) {
                    firstName = getRandomMaleName();
                } else {
                    firstName = getRandomFemaleName();
                }
            } else {
                if (generateMale) {
                    firstName = getRandomMaleName();
                } else {
                    firstName = getRandomFemaleName();
                }
            }
            result += firstName;
        }
        if (generateLastName) {
            String lastName = getRandomLastName();
            if (!result.isEmpty()) {
                result += " ";
            }
            result += lastName;
        }
        return result;
    }
}
