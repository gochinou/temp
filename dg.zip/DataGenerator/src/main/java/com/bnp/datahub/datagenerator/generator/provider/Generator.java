/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.generator.provider;

import com.bnp.datahub.datagenerator.context.ExecutionContext;

import java.util.Map;

public interface Generator {

    void init(ExecutionContext context, Map<String, String> props);

    String nextValue(String familyName, String fieldName);

}
