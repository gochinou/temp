/*
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnp.datahub.datagenerator.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CsvOptions {
    private String separator;
    private String quoteChar;
    private String escapeChar;
    private String lineEnd;

    public char getSeparator() {
        return separator.charAt(0);
    }

    public char getQuoteChar() {
        return quoteChar.charAt(0);
    }

    public char getEscapeChar() {
        return escapeChar.charAt(0);
    }

    public String getLineEnd() {
        return lineEnd;
    }
}
