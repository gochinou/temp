#!/usr/bin/env bash

BIN_DIR=$(cd `dirname $0`; pwd)
LIB_DIR=$(cd $BIN_DIR/../lib; pwd)
CONF_DIR=$(cd $BIN_DIR/../config; pwd)

java -cp "$LIB_DIR/*" -Dlogback.configurationFile=$CONF_DIR/logback.xml com.bnp.datahub.datagenerator.main.Orchestrator "$@"
