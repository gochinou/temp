/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.producers;

import com.bnp.datahub.datagenerator.model.Config;
import com.bnp.datahub.datagenerator.parser.ConfParser;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.commons.io.FileUtils;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.json.JSONException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.Answer;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class DataGeneratorConfigProducerTest {

    @InjectMocks
    private DataGeneratorConfigProducer dataGeneratorConfigProducer;

    @Mock
    private Producer<String, GenericRecord> kafkaProducer;
    private Properties kafkaProperties;
    private List<GenericRecord> kafkaHistory;

    public static final ObjectMapper MAPPER = new ObjectMapper();

    static {
        SimpleModule module = new SimpleModule();
        module.addSerializer(Schema.class, new JsonSerializer<Schema>() {
            @Override
            public void serialize(Schema schema, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
                String jsonSchema = schema.toString();
                jsonGenerator.writeRaw(":" + jsonSchema);
            }
        });
        MAPPER.registerModule(module);
    }

    @Before
    public void setup() {
        kafkaProperties = new Properties();
        kafkaProperties.put("topic", "tpc-test");
        dataGeneratorConfigProducer = new DataGeneratorConfigProducer(kafkaProperties);

        Object thisClass = this;
        MockitoAnnotations.initMocks(thisClass);

        kafkaHistory = Collections.synchronizedList(new ArrayList<>());

        ExecutorService threadPool = Executors.newFixedThreadPool(10);

        when(kafkaProducer.send(any()))
            .thenAnswer((Answer<Future<RecordMetadata>>) invocationOnMock -> {
                ProducerRecord<String, GenericRecord> producerRecord = invocationOnMock.getArgument(0);
                kafkaHistory.add(producerRecord.value());
                return threadPool.submit(() -> null);
            });
    }

    @Test
    public void send_should_transform_config_to_genericRecord_and_preserve_all_properties() throws IOException, ExecutionException, InterruptedException, JSONException {
        // GIVEN
        Config config = createConfig();
        // WHEN
        dataGeneratorConfigProducer.send(config).get();
        // THEN
        Assert.assertNotNull(kafkaHistory.get(0));
    }

    private Config createConfig() throws IOException {
        URL configResource = getClass().getClassLoader().getResource("config.json");
        String jsonConfig = FileUtils.readFileToString(new File(configResource.getPath()), Charset.defaultCharset());
        return new ConfParser().deserialize(jsonConfig);
    }
}
