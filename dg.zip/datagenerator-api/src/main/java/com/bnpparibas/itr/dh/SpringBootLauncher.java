/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLauncher {
    public static void main(String[] args) {
        SpringApplication.run(SpringBootLauncher.class, args);
    }
}
