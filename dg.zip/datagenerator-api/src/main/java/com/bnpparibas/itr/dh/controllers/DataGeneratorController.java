/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.controllers;

import com.bnp.datahub.datagenerator.model.Config;
import com.bnpparibas.itr.dh.producers.DataGeneratorConfigProducer;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.Schema;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static net.logstash.logback.marker.Markers.append;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

@RestController("DataGen")
@RequestMapping("/generator")
public class DataGeneratorController {
    private static final Logger LOG = LoggerFactory.getLogger(DataGeneratorController.class);
    private static final String ROOT_CORRELATION_ID = "rootCorrelationId";
    private static final String PARENT_CORRELATION_ID = "parentCorrelationId";


    @Autowired
    private DataGeneratorConfigProducer producer;
    @Autowired
    private Schema.Parser schemaParser;

    @PostMapping("/generate")
    public ResponseEntity<String> postGenerationConfig(@RequestBody Config config) {
        LogstashMarker markers = append(ROOT_CORRELATION_ID, config.getRootCorrelationId()).and(append(PARENT_CORRELATION_ID, config.getParentCorrelationId()));
        try {
            Future<RecordMetadata> result = producer.send(config);
            LOG.info(markers,"Deserializing Config");
            result.get();
        } catch ( Throwable e) {
            LOG.error(markers,"Internal error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
        return ResponseEntity.ok("OK");
    }

    @PostMapping("/check/schema")
    public ResponseEntity<String> checkSchema(@RequestBody String jsonSchema) {
        try {
            schemaParser.parse(jsonSchema);
        } catch (Throwable e){
            LOG.error("Internal error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
        return ResponseEntity.ok("OK");
    }
}
