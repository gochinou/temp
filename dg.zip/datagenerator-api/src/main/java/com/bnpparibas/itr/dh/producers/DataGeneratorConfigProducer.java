/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.producers;

import com.bnp.datahub.datagenerator.model.Config;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.BinaryDecoder;
import org.apache.avro.io.BinaryEncoder;
import org.apache.avro.io.DecoderFactory;
import org.apache.avro.io.EncoderFactory;
import org.apache.avro.reflect.ReflectDatumWriter;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.Future;

public class DataGeneratorConfigProducer {
    private static final String TOPICS_CONFIG = "topic";
    private static final String CONFIG_SCHEMA_FILE = "config.schema";
    private static final BinaryEncoder REUSE_ENCODER = null;
    private static final BinaryDecoder REUSE_DECODER = null;
    private static final GenericRecord REUSE_CONFIG = null;
    private static Schema configSchema = null;

    private String topic;
    private Producer<String, GenericRecord> producer;
    private Properties kafkaProperties;

    public DataGeneratorConfigProducer(Properties properties) {
        topic = properties.getProperty(TOPICS_CONFIG);
        kafkaProperties = new Properties();
        kafkaProperties.putAll(properties);
    }

    synchronized private void setupKafkaProducer(){
        if(producer == null){
            producer = new KafkaProducer<>(kafkaProperties);
        }
    }

    public Future<RecordMetadata> send(Config config) throws IOException {
        setupKafkaProducer();
        GenericRecord genericRecord = configToGenericRecord(config);
        ProducerRecord<String, GenericRecord> record = new ProducerRecord<>(topic, UUID.randomUUID().toString(), genericRecord);
        return producer.send(record);
    }

    private GenericRecord configToGenericRecord(Config config) throws IOException {
        byte[] bytes = configToBytes(config);
        return bytesToGenericRecord(bytes);
    }

    private GenericRecord bytesToGenericRecord(byte[] bytes) throws IOException {
        Schema newConfigSchema = getConfigSchema();
        GenericDatumReader<GenericRecord> datumReader = new GenericDatumReader<>(newConfigSchema);
        BinaryDecoder decoder = DecoderFactory.get().binaryDecoder(bytes, REUSE_DECODER);
        return datumReader.read(REUSE_CONFIG, decoder);
    }

    private byte[] configToBytes(Config config) throws IOException {
        try (ByteArrayOutputStream bytesStream = new ByteArrayOutputStream()) {
            Schema newConfigSchema = getConfigSchema();
            ReflectDatumWriter<Config> datumWriter = new ReflectDatumWriter<>(newConfigSchema);
            BinaryEncoder encoder = EncoderFactory.get().binaryEncoder(bytesStream, REUSE_ENCODER);
            datumWriter.write(config, encoder);
            encoder.flush();
            return bytesStream.toByteArray();
        }
    }

    synchronized private Schema getConfigSchema() throws IOException {
        if(configSchema == null){
            InputStream configSchemaAsStream = getClass().getClassLoader().getResourceAsStream(CONFIG_SCHEMA_FILE);
            configSchema = new Schema.Parser().parse(configSchemaAsStream);
        }
        return configSchema;
    }

    public void close(){
        if(producer != null){
            producer.close();
        }
    }
}
