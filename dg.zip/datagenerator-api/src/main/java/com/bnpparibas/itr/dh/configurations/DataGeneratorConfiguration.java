/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.configurations;

import com.bnpparibas.itr.dh.producers.DataGeneratorConfigProducer;
import com.bnpparibas.itr.dh.serializers.ConfigDeserializer;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.avro.Schema;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

@Configuration
public class DataGeneratorConfiguration {
    private static final String KAFKA_PROPS_FILE = "kafka.properties";

    @Bean
    public DataGeneratorConfigProducer producer() throws IOException {
        Properties kafkaProperties = new Properties();
        InputStream kafkaPropsInputStream = getClass().getClassLoader().getResourceAsStream(KAFKA_PROPS_FILE);
        kafkaProperties.load(kafkaPropsInputStream);

        kafkaProperties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        kafkaProperties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class.getName());

        return new DataGeneratorConfigProducer(kafkaProperties);
    }

    @Bean
    public Schema.Parser schemaParser(){
        return new Schema.Parser();
    }

    @Bean(initMethod = "init")
    public ConfigDeserializer configDeserializer(){
        return new ConfigDeserializer();
    }
}
