/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.serializers;

import com.bnp.datahub.datagenerator.generator.provider.CorrelationIdGenerator;
import com.bnp.datahub.datagenerator.model.Config;
import com.bnp.datahub.datagenerator.parser.SchemaDeserializer;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import net.logstash.logback.marker.LogstashMarker;
import org.apache.avro.Schema;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.util.Map;

import static net.logstash.logback.marker.Markers.append;

public class ConfigDeserializer extends JsonDeserializer<Config> {

    private static final Logger LOG = LoggerFactory.getLogger(ConfigDeserializer.class);

    private static final String ROOT_CORRELATION_ID = "rootCorrelationId";
    private static final String PARENT_CORRELATION_ID = "parentCorrelationId";
    private static final String CORRELATION_ID = "correlationId";

    private static final ObjectMapper MAPPER = new ObjectMapper();

    static {
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addDeserializer(Schema.class, new SchemaDeserializer());
        MAPPER.registerModule(simpleModule);
    }

    @Autowired
    private ObjectMapper mapper;

    public void init(){
        SimpleModule simpleModule = new SimpleModule();
        ConfigDeserializer configDeserializer = this;
        simpleModule.addDeserializer(Config.class, configDeserializer);
        mapper.registerModule(simpleModule);
    }

    @Override
    public Config deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException {
        CorrelationIdGenerator generator = new CorrelationIdGenerator();
        Map map = jsonParser.readValueAs(Map.class);
        Object rootCorrelationId = map.get(ROOT_CORRELATION_ID);
        Object parentCorrelationId = map.get(PARENT_CORRELATION_ID);
        String correlationId = generator.nextValue(StringUtils.EMPTY, StringUtils.EMPTY);

        if (rootCorrelationId ==  null) {
            rootCorrelationId = correlationId;
        }
        if (parentCorrelationId ==  null) {
            parentCorrelationId = rootCorrelationId;
        }
        LogstashMarker markers = append(ROOT_CORRELATION_ID, rootCorrelationId).and(append(PARENT_CORRELATION_ID, parentCorrelationId).and(append(CORRELATION_ID, correlationId)));
        LOG.info(markers,"Deserializing Config...");

        map.put(ROOT_CORRELATION_ID, rootCorrelationId);
        map.put(PARENT_CORRELATION_ID, correlationId);
        String jsonConfig = mapper.writeValueAsString(map);
        return MAPPER.readValue(jsonConfig, Config.class);
    }
}
