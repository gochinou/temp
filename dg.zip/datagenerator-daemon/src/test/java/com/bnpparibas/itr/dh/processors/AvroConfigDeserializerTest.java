/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.processors;

import com.bnp.datahub.datagenerator.model.Config;
import org.apache.avro.Schema;
import org.apache.avro.UnresolvedUnionException;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.reflect.ReflectData;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;

public class AvroConfigDeserializerTest {
    public static final String CSV = "csv";
    public static final GenericRecord NULL_GENERIC_RECORD = null;
    public static final String CONFIG_SCHEMA_FILE = "test-config.schema";
    private static GenericRecord stringSchema;
    private static Schema schema;
    private AvroConfigDeserializer avroConfigDeserializer;

    public AvroConfigDeserializerTest() throws IOException {
        avroConfigDeserializer = new AvroConfigDeserializer();
    }

    @BeforeClass
    public static void setup() throws IOException {
        Schema stringSchemaSchema = Schema.create(Schema.Type.STRING);
        Schema schemaAvroSchema = ReflectData.AllowNull.get().getSchema(stringSchemaSchema.getClass());
        stringSchema = new GenericData.Record(schemaAvroSchema);
        stringSchema.put("hashCode", stringSchemaSchema.hashCode());

        InputStream SCHEMA_AS_STREAM = Schema.class.getClassLoader().getResourceAsStream(CONFIG_SCHEMA_FILE);
        schema = new Schema.Parser().parse(SCHEMA_AS_STREAM);
    }

    @Test
    public void notNullSchema_should_not_throw_IOException() throws IOException {
        // GIVEN
        GenericRecord gr = generateGenericRecord(CSV, Integer.MIN_VALUE, stringSchema);
        //  WHEN
        Config conf = avroConfigDeserializer.genericRecordToConfig(gr);
        // THEN
        Assert.assertNotNull(conf);
    }

    @Test(expected = UnresolvedUnionException.class)
    public void nullSchema_throw_IOException() throws IOException {
        // GIVEN
        GenericRecord gr = generateGenericRecord(CSV, Integer.MIN_VALUE, NULL_GENERIC_RECORD);
        //  WHEN
        Config conf = avroConfigDeserializer.genericRecordToConfig(gr);
        // THEN an exception is raised
    }

    @Test
    public void csvOuput_in_GR_should_give_csvOutput_in_conf() throws IOException {
        // GIVEN
        GenericRecord gr = generateGenericRecord(CSV, Integer.MIN_VALUE, stringSchema);
        //  WHEN
        Config conf = avroConfigDeserializer.genericRecordToConfig(gr);
        // THEN
        Assert.assertEquals(conf.getOutput(), "csv");
    }

    private GenericRecord generateGenericRecord(String output, int naughtyStringsPerc, GenericRecord schemaAvro) {
        GenericRecord gr = new GenericData.Record(schema);
        gr.put("output", output);
        gr.put("naughtyStringsPerc", naughtyStringsPerc);
        gr.put("schemaAvro", schemaAvro);
        return gr;
    }
}
