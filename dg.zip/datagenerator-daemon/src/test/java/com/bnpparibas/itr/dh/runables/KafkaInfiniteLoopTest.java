/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.runables;

import org.apache.kafka.common.config.ConfigException;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class KafkaInfiniteLoopTest {

    private static final Properties kafkaProperties = new Properties();

    @BeforeClass
    public static void setup() throws IOException {
        InputStream resource = KafkaInfiniteLoopTest.class.getClassLoader().getResourceAsStream("kafka.properties");
        kafkaProperties.load(resource);
    }

    @Test(expected = ConfigException.class)
    public void infiniteLoop_constructor_should_throw_ConfigException_when_kafka_properties_is_empty() throws IOException {
        // GIVEN
        Properties kafkaProperties = new Properties();
        // WHEN
        new KafkaInfiniteLoop(kafkaProperties);
        // THEN ConfigException is raised
    }

    @Test
    public void stop_should_stop_the_thread_with_KafkaInfiniteLoop() throws IOException, InterruptedException {
        // GIVEN
        KafkaInfiniteLoop kafkaInfiniteLoop = new KafkaInfiniteLoop(kafkaProperties);
        Thread thread = new Thread(kafkaInfiniteLoop);
        thread.start();
        // WHEN
        kafkaInfiniteLoop.stop();
        thread.join();
        // THEN
        Assert.assertFalse(thread.isAlive());
    }
}
