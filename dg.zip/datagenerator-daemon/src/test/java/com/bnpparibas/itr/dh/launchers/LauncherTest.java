/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.launchers;

import org.junit.Test;

import java.net.URL;

public class LauncherTest {

    @Test
    public void test_main(){
        URL resource = getClass().getClassLoader().getResource("kafka.properties");
        Launcher.main(new String[]{ resource.getPath() });
    }
}
