/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.reflect;

import org.apache.avro.Schema;
import org.apache.avro.reflect.ReflectData;
import org.junit.Assert;
import org.junit.Test;

public class ConfigDataTest {

    private ConfigData configData = new ConfigData();
    private Object NULL_VALUE = null;

    private Class<?> recordSchemaClass = getClass().getClassLoader().loadClass(ConfigData.ORG_APACHE_AVRO_SCHEMA_RECORD_SCHEMA);
    private Class<?> unionSchemaClass = getClass().getClassLoader().loadClass(ConfigData.ORG_APACHE_AVRO_SCHEMA_UNION_SCHEMA);
    private Class<?> fieldSchemaClass = getClass().getClassLoader().loadClass(ConfigData.ORG_APACHE_AVRO_SCHEMA_FIELD);
    private Class<?> nameSchemaClass = getClass().getClassLoader().loadClass(ConfigData.ORG_APACHE_AVRO_SCHEMA_NAME);
    private Class<?> arraySchemaClass = getClass().getClassLoader().loadClass(ConfigData.ORG_APACHE_AVRO_SCHEMA_ARRAY_SCHEMA);
    private Class<?> enumSchemaClass = getClass().getClassLoader().loadClass(ConfigData.ORG_APACHE_AVRO_SCHEMA_ENUM_SCHEMA);
    private Class<?> fixedSchemaClass = getClass().getClassLoader().loadClass(ConfigData.ORG_APACHE_AVRO_SCHEMA_FIXED_SCHEMA);
    private Class<?> mapSchemaClass = getClass().getClassLoader().loadClass(ConfigData.ORG_APACHE_AVRO_SCHEMA_MAP_SCHEMA);

    public ConfigDataTest() throws ClassNotFoundException {

    }

    @Test
    public void newRecord_should_return_RecordSchema_when_schema_is_RecordSchema(){
        // GIVEN
        Schema schema = ReflectData.AllowNull.get().getSchema(recordSchemaClass);
        // WHEN
        Object result = configData.newRecord(NULL_VALUE, schema);
        // THEN
        Assert.assertSame(recordSchemaClass, result.getClass());
    }

    @Test
    public void newRecord_should_return_unionSchema_when_schema_is_unionSchema(){
        // GIVEN
        Schema schema = ReflectData.AllowNull.get().getSchema(unionSchemaClass);
        // WHEN
        Object result = configData.newRecord(NULL_VALUE, schema);
        // THEN
        Assert.assertSame(unionSchemaClass, result.getClass());
    }

    @Test
    public void newRecord_should_return_fieldSchema_when_schema_is_fieldSchema(){
        // GIVEN
        Schema schema = ReflectData.AllowNull.get().getSchema(fieldSchemaClass);
        // WHEN
        Object result = configData.newRecord(NULL_VALUE, schema);
        // THEN
        Assert.assertSame(fieldSchemaClass, result.getClass());
    }

    @Test
    public void newRecord_should_return_nameSchema_when_schema_is_nameSchema(){
        // GIVEN
        Schema schema = ReflectData.AllowNull.get().getSchema(nameSchemaClass);
        // WHEN
        Object result = configData.newRecord(NULL_VALUE, schema);
        // THEN
        Assert.assertSame(nameSchemaClass, result.getClass());
    }

    @Test
    public void newRecord_should_return_arraySchema_when_schema_is_arraySchema(){
        // GIVEN
        Schema schema = ReflectData.AllowNull.get().getSchema(arraySchemaClass);
        // WHEN
        Object result = configData.newRecord(NULL_VALUE, schema);
        // THEN
        Assert.assertSame(arraySchemaClass, result.getClass());
    }

    @Test
    public void newRecord_should_return_enumSchema_when_schema_is_enumSchema(){
        // GIVEN
        Schema schema = ReflectData.AllowNull.get().getSchema(enumSchemaClass);
        // WHEN
        Object result = configData.newRecord(NULL_VALUE, schema);
        // THEN
        Assert.assertSame(enumSchemaClass, result.getClass());
    }

    @Test
    public void newRecord_should_return_fixedSchema_when_schema_is_fixedSchema(){
        // GIVEN
        Schema schema = ReflectData.AllowNull.get().getSchema(fixedSchemaClass);
        // WHEN
        Object result = configData.newRecord(NULL_VALUE, schema);
        // THEN
        Assert.assertSame(fixedSchemaClass, result.getClass());
    }

    @Test
    public void newRecord_should_return_mapSchema_when_schema_is_mapSchema(){
        // GIVEN
        Schema schema = ReflectData.AllowNull.get().getSchema(mapSchemaClass);
        // WHEN
        Object result = configData.newRecord(NULL_VALUE, schema);
        // THEN
        Assert.assertSame(mapSchemaClass, result.getClass());
    }
}
