/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.processors;

import com.bnp.datahub.datagenerator.model.Config;
import com.bnpparibas.itr.dh.readers.SchemaDatumReader;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.BinaryDecoder;
import org.apache.avro.io.BinaryEncoder;
import org.apache.avro.io.Decoder;
import org.apache.avro.io.DecoderFactory;
import org.apache.avro.io.Encoder;
import org.apache.avro.io.EncoderFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class AvroConfigDeserializer {
    private static final Config REUSE_CONFIG = null;
    private static final BinaryEncoder REUSE_ENCODER = null;
    private static final BinaryDecoder REUSE_DECODER = null;

    private static final String CONFIG_SCHEMA_FILE = "config.schema";

    private static Schema configSchema;

    private SchemaDatumReader datumReader;
    private GenericDatumWriter<GenericRecord> datumWriter;

    public AvroConfigDeserializer() throws IOException {
        initConfigSchema();
        datumReader = new SchemaDatumReader(configSchema);
        datumWriter = new GenericDatumWriter<>(configSchema);
    }

    private synchronized void initConfigSchema() throws IOException {
        if(configSchema == null){
            InputStream configSchemaAsStream = getClass().getClassLoader().getResourceAsStream(CONFIG_SCHEMA_FILE);
            configSchema = new Schema.Parser().parse(configSchemaAsStream);
        }
    }

    public Config genericRecordToConfig(GenericRecord genericRecord) throws IOException {
        byte[] bytes = configGenericRecordToBytes(genericRecord);
        Config config = bytesToConfig(bytes);
        return config;
    }

    private Config bytesToConfig(byte[] bytes) throws IOException {
        Decoder decoder = DecoderFactory.get().binaryDecoder(bytes, REUSE_DECODER);
        return datumReader.read(REUSE_CONFIG, decoder);
    }

    private byte[] configGenericRecordToBytes(GenericRecord genericRecord) throws IOException {
        try (ByteArrayOutputStream bytesStream = new ByteArrayOutputStream()) {
            Encoder encoder = EncoderFactory.get().binaryEncoder(bytesStream, REUSE_ENCODER);
            datumWriter.write(genericRecord, encoder);
            encoder.flush();
            bytesStream.close();
            return bytesStream.toByteArray();
        }
    }
}
