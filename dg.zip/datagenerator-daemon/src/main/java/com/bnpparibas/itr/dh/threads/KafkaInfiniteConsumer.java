/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.threads;

import com.bnpparibas.itr.dh.runables.KafkaInfiniteLoop;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

public class KafkaInfiniteConsumer extends Thread {
    private static final Logger LOG = LoggerFactory.getLogger(KafkaInfiniteConsumer.class);

    private static final List<KafkaInfiniteLoop> kafkaInfiniteLoops = Collections.synchronizedList(new ArrayList<KafkaInfiniteLoop>());
    private static Thread shutdownHook = null;

    public KafkaInfiniteConsumer(Properties kafkaProperties) throws IOException {
        super(newKafkaInfinitLoop(kafkaProperties));
    }

    private static KafkaInfiniteLoop newKafkaInfinitLoop(Properties kafkaProperties) throws IOException {
        KafkaInfiniteLoop kafkaInfinitLoop = new KafkaInfiniteLoop(kafkaProperties);
        kafkaInfiniteLoops.add(kafkaInfinitLoop);
        return kafkaInfinitLoop;
    }

    synchronized public static Thread getShutdownHook() {
        if (shutdownHook == null) {
            LOG.info("Init kafka consumer shutdown hook");
            shutdownHook = new Thread(() -> {
                LOG.info("ShutdownHook called");
                LOG.info("Shutdown all kafka infinite loops ...");
                for (KafkaInfiniteLoop loop : kafkaInfiniteLoops) {
                    loop.stop();
                }
            });
        }
        return shutdownHook;
    }
}
