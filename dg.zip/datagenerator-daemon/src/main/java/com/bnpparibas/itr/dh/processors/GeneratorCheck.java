/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.processors;

import com.bnpparibas.itr.dh.exceptions.GeneratorCheckException;

public interface GeneratorCheck {
    void check() throws GeneratorCheckException;
}
