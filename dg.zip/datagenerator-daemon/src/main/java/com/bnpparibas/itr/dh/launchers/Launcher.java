/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.launchers;

import com.bnpparibas.itr.dh.threads.KafkaInfiniteConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Launcher {
    private static final Logger LOG = LoggerFactory.getLogger(Launcher.class);
    private static final String KAFKA_PROPS_ERROR = "Kafka file properties is not optional";

    public static void main(String[] args){
        try {
            checkParams(args);
            Properties kafkaProperties = getKafkaProperties(args[0]);

            KafkaInfiniteConsumer kafkaConsumer = new KafkaInfiniteConsumer(kafkaProperties);

            kafkaConsumer.start();
            Thread kafkaConsumerShutdownHook = KafkaInfiniteConsumer.getShutdownHook();

            Runtime.getRuntime().addShutdownHook(kafkaConsumerShutdownHook);
        } catch (Exception ex) {
            LOG.error("Internal error", ex);
        }
    }

    private static Properties getKafkaProperties(String arg) throws IOException {
        Properties kafkaProperties = new Properties();
        kafkaProperties.load(new FileInputStream(arg));
        return kafkaProperties;
    }

    private static void checkParams(String[] args) throws Exception {
        if (args.length == 0) {
            throw new Exception(KAFKA_PROPS_ERROR);
        }
    }
}
