/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.reflect;

import org.apache.avro.Schema;
import org.apache.avro.reflect.ReflectData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class ConfigData extends ReflectData {
    private static final Logger LOG = LoggerFactory.getLogger(ConfigData.class);

    private static final ConfigData INSTANCE = new ConfigData();

    static final String ORG_APACHE_AVRO_SCHEMA_RECORD_SCHEMA = "org.apache.avro.Schema$RecordSchema";
    static final String ORG_APACHE_AVRO_SCHEMA_FIELD = "org.apache.avro.Schema$Field";
    static final String ORG_APACHE_AVRO_SCHEMA_NAME = "org.apache.avro.Schema$Name";
    static final String ORG_APACHE_AVRO_SCHEMA_ARRAY_SCHEMA = "org.apache.avro.Schema$ArraySchema";
    static final String ORG_APACHE_AVRO_SCHEMA_ENUM_SCHEMA = "org.apache.avro.Schema$EnumSchema";
    static final String ORG_APACHE_AVRO_SCHEMA_FIXED_SCHEMA = "org.apache.avro.Schema$FixedSchema";
    static final String ORG_APACHE_AVRO_SCHEMA_MAP_SCHEMA = "org.apache.avro.Schema$MapSchema";
    static final String ORG_APACHE_AVRO_SCHEMA_UNION_SCHEMA = "org.apache.avro.Schema$UnionSchema";

    private static final Object NULL_VALUE = null;
    private static final String FIELD_NAME_VALUE = "FieldName";
    private static final String RECORD_SCHEMA_NAME_VALUE = "RecordSchema";
    private static final String RECORD_SCHEMA_NAMESPACE_VALUE = "org.apache.avro.Schema$";
    private static final List<Schema.Field> FIELDS = new ArrayList<>();
    private static final int MIN_VALUE = 0;
    private static final List<String> VALUES = new ArrayList<>();
    private static final String NAME = null;
    private static final String DOC = null;
    private static final String NAMESPACE = null;
    private static final String SPACE = null;
    private static final Schema ELEMENT_TYPE = null;

    public static ReflectData getInstance() {
        return INSTANCE;
    }

    @Override
    public Object newRecord(Object old, Schema schema) {
        Class schemaClass = getClass(schema);
        if (ORG_APACHE_AVRO_SCHEMA_RECORD_SCHEMA.equals(schemaClass.getName())) {
            old = Schema.createRecord(FIELDS);
        } else if (ORG_APACHE_AVRO_SCHEMA_FIELD.equals(schemaClass.getName())) {
            old = buildSchemaField();
        } else if (ORG_APACHE_AVRO_SCHEMA_NAME.equals(schemaClass.getName())) {
            old = buildSchemaName();
        } else if (ORG_APACHE_AVRO_SCHEMA_ARRAY_SCHEMA.equals(schemaClass.getName())) {
            old = Schema.createArray(ELEMENT_TYPE);
        } else if (ORG_APACHE_AVRO_SCHEMA_ENUM_SCHEMA.equals(schemaClass.getName())) {
            old = Schema.createEnum(NAME, DOC, NAMESPACE, VALUES);
        } else if (ORG_APACHE_AVRO_SCHEMA_FIXED_SCHEMA.equals(schemaClass.getName())) {
            old = Schema.createFixed(NAME, DOC, SPACE, MIN_VALUE);
        } else if (ORG_APACHE_AVRO_SCHEMA_MAP_SCHEMA.equals(schemaClass.getName())) {
            old = Schema.createMap(null);
        } else if (ORG_APACHE_AVRO_SCHEMA_UNION_SCHEMA.equals(schemaClass.getName())) {
            old = Schema.createUnion();
        }
        return super.newRecord(old, schema);
    }

    private Object buildSchemaField(){
        try {
            Optional<Class<?>> optionalFieldClass = Arrays.asList(Schema.class.getDeclaredClasses()).stream().filter(clazz -> ORG_APACHE_AVRO_SCHEMA_FIELD.equals(clazz.getName())).findFirst();
            if(!optionalFieldClass.isPresent()){
                throw new RuntimeException("Schema field class is absent");
            }
            Class<?> fieldClass = optionalFieldClass.get();
            Constructor fieldConstructor = fieldClass.getDeclaredConstructor(String.class, Schema.class, String.class, Object.class);
            fieldConstructor.setAccessible(true);
            Object[] args = {FIELD_NAME_VALUE, NULL_VALUE, NULL_VALUE, NULL_VALUE};
            return fieldConstructor.newInstance(args);
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
            LOG.error("Error during building Schema Fields", e);
            throw new RuntimeException(e);
        }
    }

    private Object buildSchemaName() {
        try {
            Optional<Class<?>> optionalNameClass = Arrays.asList(Schema.class.getDeclaredClasses()).stream().filter(clazz -> ORG_APACHE_AVRO_SCHEMA_NAME.equals(clazz.getName())).findFirst();
            if(!optionalNameClass.isPresent()){
                throw new RuntimeException("Schema name class is absent");
            }
            Class<?> schemaNameClass = optionalNameClass.get();
            Constructor<?> schemaNameConstructor = schemaNameClass.getDeclaredConstructor(String.class, String.class);
            schemaNameConstructor.setAccessible(true);
            Object[] args = {RECORD_SCHEMA_NAME_VALUE, RECORD_SCHEMA_NAMESPACE_VALUE};
            return schemaNameConstructor.newInstance(args);
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
            LOG.error("Error during building Schema Fields", e);
            throw new RuntimeException(e);
        }
    }
}
