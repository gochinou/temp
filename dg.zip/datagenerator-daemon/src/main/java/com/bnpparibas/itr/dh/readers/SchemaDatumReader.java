/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.readers;

import com.bnp.datahub.datagenerator.model.Config;
import com.bnpparibas.itr.dh.reflect.ConfigData;
import org.apache.avro.Schema;
import org.apache.avro.reflect.ReflectDatumReader;

public class SchemaDatumReader extends ReflectDatumReader<Config> {

    public SchemaDatumReader(Schema root){
        super(root, root, ConfigData.getInstance());
    }
}
