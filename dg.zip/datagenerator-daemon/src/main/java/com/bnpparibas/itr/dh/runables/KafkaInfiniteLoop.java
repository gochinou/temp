/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.runables;

import com.bnp.datahub.datagenerator.main.Core;
import com.bnp.datahub.datagenerator.model.Config;
import com.bnpparibas.itr.dh.exceptions.GeneratorCheckException;
import com.bnpparibas.itr.dh.processors.AvroConfigDeserializer;
import com.bnpparibas.itr.dh.processors.GeneratorCheck;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;

public class KafkaInfiniteLoop implements Runnable {
    private static final Logger LOG = LoggerFactory.getLogger(KafkaInfiniteLoop.class);

    private static final long POOL_TIME_OUT = 1000;
    private static final String INTERNAL_ERROR = "Internal error";
    private String DATA_GENERATOR_INTERNAL_ERROR = "Data generator internal error";
    private static final String CONSUMER_SHUTTING_DOWN_LOG = "Consumer shutting down";
    private static final String TOPICS_CONFIG = "topics";
    private static final String TOPICS_CONFIG_SEP = ",";

    private CountDownLatch countDownLatch = new CountDownLatch(1);
    private AvroConfigDeserializer avroConfigDeserializer = new AvroConfigDeserializer();

    private KafkaConsumer<String, GenericRecord> consumer;

    private List<GeneratorCheck> checks = new ArrayList<>();

    public KafkaInfiniteLoop(Properties kafkaProperties) throws IOException {
        overrideKafkaProps(kafkaProperties);
        consumer = new KafkaConsumer<>(kafkaProperties);

        List<String> topics = getTopicsFromProps(kafkaProperties);
        consumer.subscribe(topics);
    }

    private List<String> getTopicsFromProps(Properties kafkaProperties) {
        return Arrays.asList(kafkaProperties.getProperty(TOPICS_CONFIG).split(TOPICS_CONFIG_SEP));
    }

    private void overrideKafkaProps(Properties kafkaProperties) {
        kafkaProperties.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        kafkaProperties.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, KafkaAvroDeserializer.class.getName());
        kafkaProperties.setProperty(ConsumerConfig.GROUP_ID_CONFIG, UUID.randomUUID().toString());
    }

    public void addCheck(GeneratorCheck check){
        checks.add(check);
    }

    public void run() {
        try {
            infiniteConsume();
        } catch (WakeupException wakeupEx) {
            LOG.info(CONSUMER_SHUTTING_DOWN_LOG);
        } catch (Throwable ex) {
            LOG.error(INTERNAL_ERROR, ex);
        } finally {
            closeLoop();
        }
    }

    private void infiniteConsume() {
        while (true) {
            ConsumerRecords<String, GenericRecord> records = consumer.poll(POOL_TIME_OUT);
            try{
                for (ConsumerRecord<String, GenericRecord> record : records) {
                    GenericRecord genericRecord = record.value();
                    Config config = avroConfigDeserializer.genericRecordToConfig(genericRecord);
                    for(GeneratorCheck check : checks){
                        check.check();
                    }
                    Core.process(config);
                }
            }catch(IOException | GeneratorCheckException ex){
                LOG.error(DATA_GENERATOR_INTERNAL_ERROR, ex);
            }
        }
    }

    private void closeLoop() {
        consumer.close();
        countDownLatch.countDown();
    }

    public void stop() {
        consumer.wakeup();
        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            LOG.error(INTERNAL_ERROR, e);
            Thread.currentThread().interrupt();
        }
    }
}
