/**
 * Copyright © BNP PARIBAS - All rights reserved.
 */
package com.bnpparibas.itr.dh.exceptions;

public class GeneratorCheckException extends Exception {
}
